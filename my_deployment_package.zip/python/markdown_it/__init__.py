"""A Python port of Markdown-It"""
__all__ = ("MarkdownIt",)
__version__ = "3.0.0"

from .main import MarkdownIt
